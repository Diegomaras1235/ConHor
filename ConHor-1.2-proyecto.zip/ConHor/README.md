# Con/Hor 1.2

Control de horas de trabajo para Android.

## Jornada de 45 horas semanales
Con/Hor permite elegir entre dos distribuciones habituales:
- Régimen A: lunes a viernes, 9 h por día = 45 h/semana.
- Régimen B: lunes a viernes, 8 h por día + sábado 5 h = 45 h/semana.

Las horas que superen el objetivo diario configurado se calculan como extra al 150%. El objetivo es configurable para cada día.

## Feriados
Los feriados nacionales argentinos incluidos offline se identifican automáticamente. Una jornada de feriado puede marcarse para agregar +100% sobre las horas trabajadas.

## Períodos
- Quincenal: 1–15 y 16–fin de mes.
- Mensual: 27–26.

## Compilación sin PC
El proyecto incluye `.github/workflows/build-apk.yml`. Subiéndolo a un repositorio de GitHub, el workflow puede compilar `app-debug.apk` en la nube y dejarlo disponible como artifact para descargar desde el celular.

## Nota
Esta es una versión de prueba. Antes de usarla para liquidación real conviene verificar cálculos con varias jornadas y el criterio exacto de convenio/empleador para feriados y horas extra.
