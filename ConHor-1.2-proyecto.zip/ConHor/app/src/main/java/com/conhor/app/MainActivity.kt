package com.conhor.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import kotlin.math.roundToInt
import org.json.JSONArray
import org.json.JSONObject

private val AR = Locale("es", "AR")
private val DATE_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy")
private val TIME_FMT = DateTimeFormatter.ofPattern("HH:mm")
private val MONTH_FMT = DateTimeFormatter.ofPattern("MMMM yyyy", AR)

private data class Shift(
    val id: Long,
    val start: String,
    val end: String? = null,
    val holiday: Boolean = false,
    val holidayPremium: Boolean = false,
    val note: String = ""
)

private enum class PeriodMode { FORTNIGHTLY, MONTHLY }

private class Store(context: Context) {
    private val p = context.getSharedPreferences("conhor", Context.MODE_PRIVATE)
    var name: String get() = p.getString("name", "") ?: ""; set(v) = p.edit().putString("name", v).apply()
    var rate: Double get() = p.getFloat("rate", 0f).toDouble(); set(v) = p.edit().putFloat("rate", v.toFloat()).apply()
    var targetMonFri: Double get() = p.getFloat("targetMonFri", 9f).toDouble(); set(v) = p.edit().putFloat("targetMonFri", v.toFloat()).apply()
    var targetSaturday: Double get() = p.getFloat("targetSaturday", 5f).toDouble(); set(v) = p.edit().putFloat("targetSaturday", v.toFloat()).apply()
    var targetSunday: Double get() = p.getFloat("targetSunday", 0f).toDouble(); set(v) = p.edit().putFloat("targetSunday", v.toFloat()).apply()
    var mode: PeriodMode get() = PeriodMode.valueOf(p.getString("mode", PeriodMode.FORTNIGHTLY.name)!!); set(v) = p.edit().putString("mode", v.name).apply()
    var shifts: MutableList<Shift>
        get() {
            val a = JSONArray(p.getString("shifts", "[]"))
            return MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Shift(o.getLong("id"), o.getString("start"), if (o.has("end") && !o.isNull("end")) o.getString("end") else null,
                    o.optBoolean("holiday"), o.optBoolean("premium"), o.optString("note"))
            }
        }
        set(v) {
            val a = JSONArray(); v.forEach { s ->
                a.put(JSONObject().apply { put("id", s.id); put("start", s.start); put("end", s.end); put("holiday", s.holiday); put("premium", s.holidayPremium); put("note", s.note) })
            p.edit().putString("shifts", a.toString()).apply()
        }
}

private fun money(v: Double): String = NumberFormat.getCurrencyInstance(AR).apply { maximumFractionDigits = 0 }.format(v)
private fun fmtDate(s: String) = LocalDateTime.parse(s).format(DATE_FMT)
private fun fmtTime(s: String) = LocalDateTime.parse(s).format(TIME_FMT)
private fun hours(start: String, end: String): Double = Duration.between(LocalDateTime.parse(start), LocalDateTime.parse(end)).toMinutes() / 60.0

private fun targetFor(date: LocalDate, store: Store): Double = when (date.dayOfWeek) {
    DayOfWeek.SATURDAY -> store.targetSaturday
    DayOfWeek.SUNDAY -> store.targetSunday
    else -> store.targetMonFri
}

// Argentine national holidays used by the first offline version. The list is easy to extend/update yearly.
private fun holidayName(d: LocalDate): String? = when (d.monthValue to d.dayOfMonth) {
    1 to 1 -> "Año Nuevo"
    3 to 24 -> "Día Nacional de la Memoria por la Verdad y la Justicia"
    4 to 2 -> "Día del Veterano y de los Caídos en la Guerra de Malvinas"
    5 to 1 -> "Día del Trabajador"
    5 to 25 -> "Revolución de Mayo"
    6 to 20 -> "Paso a la Inmortalidad del General Manuel Belgrano"
    7 to 9 -> "Día de la Independencia"
    8 to 17 -> "Paso a la Inmortalidad del General José de San Martín"
    10 to 12 -> "Día del Respeto a la Diversidad Cultural"
    11 to 20 -> "Día de la Soberanía Nacional"
    12 to 8 -> "Inmaculada Concepción de María"
    12 to 25 -> "Navidad"
    else -> null
}

private fun periodFor(date: LocalDate, mode: PeriodMode): Pair<LocalDate, LocalDate> {
    return if (mode == PeriodMode.FORTNIGHTLY) {
        if (date.dayOfMonth <= 15) date.withDayOfMonth(1) to date.withDayOfMonth(15)
        else date.withDayOfMonth(16) to date.with(TemporalAdjusters.lastDayOfMonth())
    } else {
        val start = if (date.dayOfMonth >= 27) date.withDayOfMonth(27) else date.minusMonths(1).withDayOfMonth(27)
        val end = start.plusMonths(1).withDayOfMonth(26)
        start to end
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ConHorApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConHorApp(context: Context) {
    val store = remember { Store(context) }
    var screen by remember { mutableStateOf("home") }
    var shifts by remember { mutableStateOf(store.shifts) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var setup by remember { mutableStateOf(store.name.isBlank()) }
    var showHoliday by remember { mutableStateOf<Shift?>(null) }

    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); kotlinx.coroutines.delay(1000) } }

    MaterialTheme(colorScheme = lightColorScheme(primary = MaterialTheme.colorScheme.primary)) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Con/Hor", fontWeight = FontWeight.Bold) }, actions = {
                IconButton(onClick = { screen = "settings" }) { Icon(Icons.Default.Settings, "Configuración") }
            }) },
            bottomBar = { NavigationBar {
                NavigationBarItem(screen == "home", { screen = "home" }, { Icon(Icons.Default.Home, null) }, label = { Text("Inicio") })
                NavigationBarItem(screen == "history", { screen = "history" }, { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Historial") })
                NavigationBarItem(screen == "summary", { screen = "summary" }, { Icon(Icons.Default.Assessment, null) }, label = { Text("Resumen") })
            }}
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    "home" -> HomeScreen(store, shifts, now) { newList -> shifts = newList; store.shifts = newList }
                    "history" -> HistoryScreen(shifts, store, now) { showHoliday = it }
                    "summary" -> SummaryScreen(shifts, store, now)
                    "settings" -> SettingsScreen(store) { screen = "home" }
                }
            }
        }
        if (setup) SetupDialog(store) { setup = false }
        showHoliday?.let { s -> HolidayDialog(s, store) { showHoliday = null; shifts = store.shifts } }
    }
}

@Composable
private fun SetupDialog(store: Store, onDone: () -> Unit) {
    var name by remember { mutableStateOf(store.name) }
    var rate by remember { mutableStateOf(if (store.rate == 0.0) "5000" else store.rate.toInt().toString()) }
    var mode by remember { mutableStateOf(store.mode) }
    AlertDialog(onDismissRequest = {}, confirmButton = { Button(onClick = { store.name = name.trim(); store.rate = rate.replace(",", ".").toDoubleOrNull() ?: 0.0; store.mode = mode; onDone() }) { Text("Guardar") } }, title = { Text("Bienvenido a Con/Hor") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Tu nombre") }, singleLine = true)
            OutlinedTextField(rate, { rate = it }, label = { Text("Valor de la hora ($)") }, singleLine = true)
            Text("Horario normal predeterminado: 9 h lunes a viernes · 5 h sábado · 0 h domingo", fontSize = 13.sp)
            Text("Período de liquidación", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(mode == PeriodMode.FORTNIGHTLY, { mode = PeriodMode.FORTNIGHTLY }); Text("Quincenal (1–15 / 16–fin)")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(mode == PeriodMode.MONTHLY, { mode = PeriodMode.MONTHLY }); Text("Mensual (27–26)")
            }
        }
    })
}

@Composable
private fun HomeScreen(store: Store, shifts: List<Shift>, now: LocalDateTime, onChange: (MutableList<Shift>) -> Unit) {
    val active = shifts.lastOrNull { it.end == null }
    val todayHoliday = holidayName(now.toLocalDate())
    val dateText = now.format(DateTimeFormatter.ofPattern("EEEE dd 'de' MMMM", AR)).replaceFirstChar { it.uppercase() }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(dateText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        Text(now.format(TIME_FMT), fontSize = 52.sp, fontWeight = FontWeight.Bold)
        if (todayHoliday != null) Card(Modifier.fillMaxWidth().padding(vertical = 12.dp)) { Column(Modifier.padding(14.dp)) { Text("🇦🇷 FERIADO", fontWeight = FontWeight.Bold); Text(todayHoliday, fontSize = 14.sp) } }
        Spacer(Modifier.height(12.dp))
        if (active == null) {
            Text("No hay jornada activa", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = {
                val s = Shift(System.currentTimeMillis(), now.toString(), holiday = todayHoliday != null)
                val l = shifts.toMutableList(); l.add(s); onChange(l)
            }, modifier = Modifier.fillMaxWidth().height(72.dp), shape = RoundedCornerShape(20.dp)) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("INICIAR JORNADA", fontSize = 20.sp) }
        } else {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text("JORNADA ACTIVA", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Ingreso: ${fmtTime(active.start)}", fontSize = 22.sp)
                Text("Tiempo: ${formatDuration(Duration.between(LocalDateTime.parse(active.start), now))}")
            }}
            Spacer(Modifier.height(14.dp))
            Button(onClick = {
                val l = shifts.map { if (it.id == active.id) it.copy(end = now.toString()) else it }.toMutableList(); onChange(l)
            }, modifier = Modifier.fillMaxWidth().height(72.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error), shape = RoundedCornerShape(20.dp)) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("FINALIZAR JORNADA", fontSize = 20.sp) }
        }
        Spacer(Modifier.height(22.dp))
        val (ps, pe) = periodFor(now.toLocalDate(), store.mode)
        Text("Período actual", fontWeight = FontWeight.Bold)
        Text("${ps.format(DATE_FMT)} → ${pe.format(DATE_FMT)}")
        val periodShifts = shifts.filter { LocalDateTime.parse(it.start).toLocalDate() in ps..pe && it.end != null }
        val totalH = periodShifts.sumOf { hours(it.start, it.end!!) }
        Text("${formatHours(totalH)} trabajadas · ${money(calculateTotal(periodShifts, store))}", fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun HistoryScreen(shifts: List<Shift>, store: Store, now: LocalDateTime, onOpen: (Shift) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = shifts.sortedByDescending { it.start }.filter { query.isBlank() || fmtDate(it.start).contains(query) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), label = { Text("Buscar fecha (ej. 09/07/2026)") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) Text("No hay jornadas registradas.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { s ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(s) }) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(fmtDate(s.start), fontWeight = FontWeight.Bold)
                        Text(if (s.end == null) "Jornada abierta · ${fmtTime(s.start)}" else "${fmtTime(s.start)} → ${fmtTime(s.end)}")
                        if (s.holiday) Text("🇦🇷 Feriado${if (s.holidayPremium) " · +100%" else ""}", fontSize = 12.sp)
                    }
                    if (s.end != null) Text(formatHours(hours(s.start, s.end!!)), fontWeight = FontWeight.Bold)
                }}
            }
        }
    }
}

@Composable
private fun HolidayDialog(s: Shift, store: Store, onClose: () -> Unit) {
    var premium by remember { mutableStateOf(s.holidayPremium) }
    AlertDialog(onDismissRequest = onClose, confirmButton = { Button(onClick = { val l = store.shifts.map { if (it.id == s.id) it.copy(holidayPremium = premium) else it }.toMutableList(); store.shifts = l; onClose() }) { Text("Guardar") } }, title = { Text("Jornada de ${fmtDate(s.start)}") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ingreso: ${fmtTime(s.start)}")
            Text("Salida: ${s.end?.let(::fmtTime) ?: "pendiente"}")
            if (s.holiday) {
                Text("🇦🇷 ${holidayName(LocalDateTime.parse(s.start).toLocalDate()) ?: "Feriado"}")
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(premium, { premium = it }); Text("Pagar feriado con +100%") }
            }
        }
    })
}

@Composable
private fun SummaryScreen(shifts: List<Shift>, store: Store, now: LocalDateTime) {
    val (ps, pe) = periodFor(now.toLocalDate(), store.mode)
    val rows = shifts.filter { val d = LocalDateTime.parse(it.start).toLocalDate(); d in ps..pe && it.end != null }.sortedBy { it.start }
    val totalH = rows.sumOf { hours(it.start, it.end!!) }
    val total = calculateTotal(rows, store)
    val normal = rows.sumOf { minOf(hours(it.start, it.end!!), targetFor(LocalDateTime.parse(it.start).toLocalDate(), store)) }
    val extra = rows.sumOf { maxOf(0.0, hours(it.start, it.end!!) - targetFor(LocalDateTime.parse(it.start).toLocalDate(), store)) }
    val holidayH = rows.filter { it.holiday && it.holidayPremium }.sumOf { hours(it.start, it.end!!) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Resumen", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("${ps.format(DATE_FMT)} → ${pe.format(DATE_FMT)}")
        Spacer(Modifier.height(14.dp))
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Total estimado", fontSize = 15.sp); Text(money(total), fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text("Horas: ${formatHours(totalH)}")
            Text("Normales: ${formatHours(normal)}")
            Text("Extras (+50%): ${formatHours(extra)}")
            Text("Feriado (+100%): ${formatHours(holidayH)}")
            Text("Horario normal: Lun–Vie ${formatHours(store.targetMonFri)} · Sáb ${formatHours(store.targetSaturday)} · Dom ${formatHours(store.targetSunday)}")
            Text("Valor hora: ${money(store.rate)}")
        }}
        Spacer(Modifier.height(16.dp))
        Text("Detalle", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        rows.forEach { s ->
            val h = hours(s.start, s.end!!)
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                Text(fmtDate(s.start), Modifier.weight(1f)); Text(formatHours(h)); Text(money(calculateShift(s, store)), Modifier.padding(start = 12.dp))
            }
        }
    }
}

@Composable
private fun SettingsScreen(store: Store, onBack: () -> Unit) {
    var rate by remember { mutableStateOf(store.rate.toInt().toString()) }
    var monFri by remember { mutableStateOf(store.targetMonFri.toString()) }
    var saturday by remember { mutableStateOf(store.targetSaturday.toString()) }
    var sunday by remember { mutableStateOf(store.targetSunday.toString()) }
    var mode by remember { mutableStateOf(store.mode) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Configuración", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Trabajador: ${store.name}")
        OutlinedTextField(rate, { rate = it }, label = { Text("Valor hora normal ($)") }, singleLine = true)
        Text("Horas normales por día", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(monFri, { monFri = it }, label = { Text("Lunes a viernes") }, singleLine = true)
        OutlinedTextField(saturday, { saturday = it }, label = { Text("Sábados") }, singleLine = true)
        OutlinedTextField(sunday, { sunday = it }, label = { Text("Domingos") }, singleLine = true)
        Text("Por defecto: 9 h de lunes a viernes, 5 h los sábados y 0 h los domingos. Lo podés cambiar, por ejemplo a 8 h.", fontSize = 13.sp)
        Text("Las horas que superen el objetivo diario se calculan al +50%.", fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(mode == PeriodMode.FORTNIGHTLY, { mode = PeriodMode.FORTNIGHTLY }); Text("Quincenal: 1–15 / 16–fin") }
        Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(mode == PeriodMode.MONTHLY, { mode = PeriodMode.MONTHLY }); Text("Mensual: 27–26") }
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            store.rate = rate.toDoubleOrNull() ?: store.rate
            store.targetMonFri = monFri.toDoubleOrNull() ?: store.targetMonFri
            store.targetSaturday = saturday.toDoubleOrNull() ?: store.targetSaturday
            store.targetSunday = sunday.toDoubleOrNull() ?: store.targetSunday
            store.mode = mode
            onBack()
        }) { Text("Guardar cambios") }
        Text("Con/Hor 1.1 · Objetivo diario configurable · Feriados argentinos offline", Modifier.padding(top = 20.dp), fontSize = 12.sp)
    }
}

private fun calculateShift(s: Shift, store: Store): Double {
    if (s.end == null) return 0.0
    val h = hours(s.start, s.end)
    val target = targetFor(LocalDateTime.parse(s.start).toLocalDate(), store)
    val normal = minOf(h, target)
    val extra = maxOf(0.0, h - target)
    var total = normal * store.rate + extra * store.rate * 1.5
    if (s.holiday && s.holidayPremium) total += h * rate
    return total
}
private fun calculateTotal(rows: List<Shift>, store: Store) = rows.sumOf { calculateShift(it, store) }
private fun formatHours(h: Double) = "${h.toInt()} h ${((h - h.toInt()) * 60).roundToInt()} min"
private fun formatDuration(d: Duration) = "${d.toHours()} h ${(d.toMinutes() % 60)} min"
